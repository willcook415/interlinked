import { useState } from "react"
import { invoke } from "@tauri-apps/api/core"

function App() {
  const [frame, setFrame] = useState<any>(null)
  const [running, setRunning] = useState(false)

  const initGame = async () => {
    await invoke("init_game", { path: "data/leeds_v0/scenario.json" })
  }

  const stepOnce = async () => {
    const f = await invoke("step_game", {
      dtS: 60,
      recomputeQuickKpis: true
    })
    setFrame(f)
  }

  const startLoop = async () => {
    setRunning(true)
    for (let i = 0; i < 30; i++) {
      const f = await invoke("step_game", {
        dtS: 60,
        recomputeQuickKpis: true
      })
      setFrame(f)
      await new Promise(r => setTimeout(r, 200))
    }
    setRunning(false)
  }

  return (
    <div style={{ padding: 40 }}>
      <h1>Interlinked Engine Test</h1>

      <button onClick={initGame}>Init Game</button>
      <button onClick={stepOnce}>Step Once</button>
      <button onClick={startLoop} disabled={running}>
        {running ? "Running..." : "Run 30 Steps"}
      </button>

      {frame && (
        <div style={{ marginTop: 30 }}>
          <h2>Live Frame</h2>
          <p><strong>Time:</strong> {frame.t_s}s</p>
          <p><strong>Trips:</strong> {frame.kpis.total_trips}</p>
          <p><strong>Share Served:</strong> {(frame.kpis.share_trips_served * 100).toFixed(2)}%</p>
          <p><strong>Mean GC:</strong> {frame.kpis.mean_generalized_cost_s.toFixed(2)}s</p>
          <p><strong>Total Queue:</strong> {frame.queue_summary.total_queue.toFixed(2)}</p>
          <p><strong>Max Queue:</strong> {frame.queue_summary.max_queue.toFixed(2)}</p>
        </div>
      )}
    </div>
  )
}

export default App
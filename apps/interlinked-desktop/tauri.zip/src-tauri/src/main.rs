#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

use serde::{Deserialize, Serialize};
use std::sync::Mutex;
use tauri::command;

use interlinked_engine::model::Scenario;
use interlinked_engine::platform::{PlanningRunOptions, ScenarioService, SimulationService};
use interlinked_engine::sim::SimulationOutput;

// We return HistoryFrame across IPC (it is Serialize/Deserialize in your engine)
use interlinked_engine::sim::{HistoryFrame, SimHistory};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ScenarioDocumentLite {
    pub schema_version: u32,
    pub scenario: Scenario,
}

pub struct AppState {
    pub game: Mutex<Option<interlinked_engine::platform::GameState>>,
}

fn resolve_repo_path(user_path: &str) -> std::path::PathBuf {
    let p = std::path::PathBuf::from(user_path);

    // If absolute, trust it
    if p.is_absolute() {
        return p;
    }

    // Repo root = ../../../ from src-tauri (apps/interlinked-desktop/src-tauri)
    let repo_root = std::path::PathBuf::from(env!("CARGO_MANIFEST_DIR"))
        .join("..")
        .join("..")
        .join("..");

    repo_root.join(p)
}

#[command]
fn load_scenario(path: String) -> Result<ScenarioDocumentLite, String> {
    let resolved = resolve_repo_path(&path);

    let doc = ScenarioService::load_from_path(resolved.to_string_lossy().as_ref())
        .map_err(|e| format!("{e}"))?;

    Ok(ScenarioDocumentLite {
        schema_version: doc.schema_version,
        scenario: doc.scenario,
    })
}

#[command]
fn run_planning(path: String) -> Result<SimulationOutput, String> {
    let resolved = resolve_repo_path(&path);

    let doc = ScenarioService::load_from_path(resolved.to_string_lossy().as_ref())
        .map_err(|e| format!("{e}"))?;

    let out = SimulationService::run_planning(&doc, PlanningRunOptions::default())
        .map_err(|e| format!("{e}"))?;

    Ok(out)
}

#[command]
fn init_game(state: tauri::State<AppState>, path: String) -> Result<(), String> {
    let resolved = resolve_repo_path(&path);

    let doc = ScenarioService::load_from_path(resolved.to_string_lossy().as_ref())
        .map_err(|e| format!("{e}"))?;

    let gs = SimulationService::init_game_state(&doc);

    let mut guard = state.game.lock().unwrap();
    *guard = Some(gs);

    Ok(())
}

/// Step the game by dt_s seconds.
/// We do NOT expose engine GameStepRequest/GameStepOutput over IPC.
/// Instead we accept simple args and return the latest HistoryFrame (which is Serialize).
#[command]
fn step_game(
    state: tauri::State<AppState>,
    dt_s: f64,
    recompute_quick_kpis: bool,
) -> Result<HistoryFrame, String> {
    let mut guard = state.game.lock().unwrap();
    let gs = guard
        .as_mut()
        .ok_or_else(|| "game not initialised: call init_game first".to_string())?;

    let req = interlinked_engine::platform::GameStepRequest {
        recompute_quick_kpis,
        edits: Vec::new(),
    };

    SimulationService::step_game(gs, dt_s, req)?;

    interlinked_engine::platform::history_last_frame(gs)
        .ok_or_else(|| "no history frame available after step".to_string())
}

#[command]
fn history_export(state: tauri::State<AppState>) -> Result<SimHistory, String> {
    let guard = state.game.lock().unwrap();
    let gs = guard
        .as_ref()
        .ok_or_else(|| "game not initialised: call init_game first".to_string())?;
    Ok(interlinked_engine::platform::history_export(gs))
}

#[command]
fn history_clear(state: tauri::State<AppState>) -> Result<(), String> {
    let mut guard = state.game.lock().unwrap();
    let gs = guard
        .as_mut()
        .ok_or_else(|| "game not initialised: call init_game first".to_string())?;
    interlinked_engine::platform::history_clear(gs);
    Ok(())
}

fn main() {
    tauri::Builder::default()
        .manage(AppState {
            game: Mutex::new(None),
        })
        .invoke_handler(tauri::generate_handler![
            load_scenario,
            run_planning,
            init_game,
            step_game,
            history_export,
            history_clear
        ])
        .run(tauri::generate_context!())
        .expect("error while running tauri application");
}

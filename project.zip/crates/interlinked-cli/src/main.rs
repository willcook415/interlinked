use clap::{Parser, Subcommand};
use interlinked_engine::{ScenarioService, SimulationService, PlanningRunOptions};

#[derive(Parser)]
#[command(name = "interlinked")]
#[command(about = "Interlinked simulation CLI", long_about = None)]
struct Cli {
    #[command(subcommand)]
    command: Commands,
}

#[derive(Subcommand)]
enum Commands {
    /// Run a scenario JSON file and write results next to it
    Run {
        /// Path to scenario.json
        scenario_path: String,
        /// Optional output path (defaults to scenario directory / results.json)
        #[arg(long)]
        out: Option<String>,
    },
}

fn main() -> Result<(), String> {
    let cli = Cli::parse();

    match cli.command {
        Commands::Run { scenario_path, out } => {
            let doc = ScenarioService::load_from_path(&scenario_path)
                .map_err(|e| format!("load/validate error: {e}"))?;

            let output = SimulationService::run_planning(&doc, PlanningRunOptions::default())?;

            let out_path = out.unwrap_or_else(|| {
                let p = std::path::Path::new(&scenario_path);
                let dir = p.parent().unwrap_or_else(|| std::path::Path::new("."));
                dir.join("results.json").to_string_lossy().to_string()
            });

            // We’ll keep writing output exactly like before (results.json is SimulationOutput)
            interlinked_engine::write_json_to_path(&out_path, &output).map_err(|e| format!("write error: {e}"))?;

            println!("✅ Ran scenario: {}", output.meta.scenario_name);
            println!("➡️  Wrote results to: {}", out_path);
            println!("Trips: {:.2}", output.kpis.total_trips);

            Ok(())
        }
    }
}
pub mod io;
pub mod model;
pub mod sim;

// NEW: platform façade
pub mod platform;

// Keep old exports for compatibility, but prefer platform::* in new code
pub use io::{load_scenario_from_path, write_json_to_path};
pub use sim::{
    compare_outputs,
    run_simulation,
    run_simulation_with_settings,
    SimulationDelta,
    SimulationOutput,
    SimulationSettings,
};

// Platform exports (the “real API” going forward)
pub use platform::{
    ComparisonService,
    GameState,
    GameStepOutput,
    GameStepRequest,
    NetworkEdit,
    NetworkStore,
    PlanningRunOptions,
    ScenarioDocument,
    ScenarioError,
    ScenarioService,
    ScenarioStore,
    SimulationService,
    WorldStore,
};
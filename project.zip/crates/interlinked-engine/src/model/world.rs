use serde::{Deserialize, Serialize};
use super::{Stop, Link, Service, Transfer, TransferRule};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct World {
    pub zones: Vec<Zone>,
    pub stops: Vec<Stop>,
    pub links: Vec<Link>,
    pub services: Vec<Service>,
    pub transfers: Vec<Transfer>,
    pub transfer_rules: Option<Vec<TransferRule>>, // NEW: mode-aware rules
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Zone {
    pub id: String,
    pub x: f64,
    pub y: f64,
    pub population: f64,
    pub jobs: f64,
}
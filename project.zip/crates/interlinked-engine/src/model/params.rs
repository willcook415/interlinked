use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Params {
    // Generalized cost weights
    pub walk_weight: f64,
    pub wait_weight: f64,
    pub ivt_weight: f64,
    pub transfer_penalty_s: f64,

    // Access/egress
    pub access_walk_speed_mps: f64,
    pub access_radius_m: f64,

    // Gravity demand
    pub gravity_beta: f64,      // deterrence parameter (per second)
    pub trips_per_person: f64,  // crude scaling: trips produced per person per period

    // --- NEW: route choice / assignment controls ---
    #[serde(default = "default_route_choice_k")]
    pub route_choice_k: usize, // number of k-shortest paths to consider per OD

    #[serde(default = "default_route_choice_theta")]
    pub route_choice_theta: f64, // logit dispersion (1/seconds): higher => more deterministic

    #[serde(default = "default_assignment_max_iters")]
    pub assignment_max_iters: usize,

    #[serde(default = "default_assignment_convergence_rel")]
    pub assignment_convergence_rel: f64, // stop when max rel change < this

    // --- NEW: capacity + queueing (milestone 2) ---
    #[serde(default = "default_capacity_enabled")]
    pub capacity_enabled: bool,

    #[serde(default = "default_queue_max_extra_wait_s")]
    pub queue_max_extra_wait_s: f64,

    // Optional: sample a specific OD instead of the first few encountered
    #[serde(default)]
    pub debug_sample_origin_zone: Option<String>,
    #[serde(default)]
    pub debug_sample_dest_zone: Option<String>,
}

fn default_route_choice_k() -> usize {
    3
}

fn default_route_choice_theta() -> f64 {
    0.002
}

fn default_assignment_max_iters() -> usize {
    8
}

fn default_assignment_convergence_rel() -> f64 {
    0.01
}

fn default_capacity_enabled() -> bool {
    true
}

fn default_queue_max_extra_wait_s() -> f64 {
    3600.0
}

pub(crate) fn default_vehicle_capacity() -> f64 {
    80.0
}
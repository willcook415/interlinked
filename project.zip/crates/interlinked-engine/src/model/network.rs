use serde::{Deserialize, Serialize};
use crate::model::params::default_vehicle_capacity;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Stop {
    pub id: String,
    pub x: f64,
    pub y: f64,

    // NEW: optional station/interchange identifier
    pub interchange_id: Option<String>,

    // NEW: optional platform/bay metadata (helps later)
    pub stop_type: Option<String>, // e.g. "bus_bay", "rail_platform", "tram_stop"
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Link {
    pub id: String,
    pub from_stop: String,
    pub to_stop: String,
    pub distance_m: f64,
    pub mode: String,
    pub speed_mps: f64,

    // Optional capacity per hour, used later (v0 just records it)
    pub capacity_per_hour: Option<f64>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Service {
    pub id: String,
    pub mode: String,
    pub stop_sequence: Vec<String>,
    pub headway_s: f64,
    pub dwell_s: f64,

    // --- NEW: capacity (per vehicle) ---
    #[serde(default = "default_vehicle_capacity")]
    pub vehicle_capacity: f64,

    // Optional extra penalty when boarding this service (e.g. station access, security, platform time)
    pub board_penalty_s: Option<f64>,
}



#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Transfer {
    pub from_stop: String,
    pub to_stop: String,
    pub time_s: f64,
    pub penalty_s: Option<f64>,
    pub allowed_modes: Option<Vec<String>>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TransferRule {
    pub from_mode: String,
    pub to_mode: String,

    // Time to interchange regardless of distance (stairs, ticket gates, finding platform)
    pub base_time_s: f64,

    // Extra “ugh” friction converted into time-equivalent seconds (reliability, inconvenience)
    pub penalty_s: f64,

    // Walking speed used when transferring between stops (m/s)
    pub walk_speed_mps: f64,

    // Optional: if stops are further than this, don't create an interchange edge
    pub max_distance_m: Option<f64>,
}
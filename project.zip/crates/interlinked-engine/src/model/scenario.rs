use serde::{Deserialize, Serialize};
use super::{Params, World};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Scenario {
    pub meta: Meta,
    pub params: Params,
    pub world: World,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Meta {
    pub name: String,
    pub seed: u64,
    pub time_period_hours: f64,
}
use serde::{Deserialize, Serialize};
use std::collections::HashMap;

use crate::model::Scenario;
use super::types::{SimulationOutput, SimulationSettings};
use super::planner::run_simulation_with_settings;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RunConfig {
    pub horizon_s: f64,
    pub time_bin_s: f64,
    pub demand: DemandConfig,
    pub emit_time_series: bool,
}

impl Default for RunConfig {
    fn default() -> Self {
        Self {
            horizon_s: 3600.0,
            time_bin_s: 300.0,
            demand: DemandConfig::default(),
            emit_time_series: true,
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SimState {
    pub t_s: f64,
    pub queue: HashMap<(String, String), f64>,
    pub time_to_next_departure_s: HashMap<(String, String), f64>,

    /// Additional OD demand (trips) to inject for the *next* simulation period.
    ///
    /// Keys are (origin_zone_id, dest_zone_id) and values are trips in this period.
    /// This is used by the stateful stepping layer to release demand events over time.
    ///
    /// IMPORTANT: This map is cleared after each step.
    #[serde(default)]
    pub pending_od_trips: HashMap<(String, String), f64>,
}

impl SimState {
    pub fn new() -> Self {
        Self {
            t_s: 0.0,
            queue: HashMap::new(),
            time_to_next_departure_s: HashMap::new(),
            pending_od_trips: HashMap::new(),
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum DemandEvent {
    // Inject additional trips at a given simulation time.
    // For now this is a scaffolding type; we will wire it into demand release next.
    ZoneToZone {
        t_s: f64,
        origin_zone: String,
        dest_zone: String,
        trips: f64,
    },
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DemandConfig {
    // Baseline synthetic demand (gravity model) is always available.
    // If true, baseline demand is used. If false, only events drive demand.
    pub use_gravity_baseline: bool,

    // Optional external demand events (good for game: festivals, stadium events, disruptions)
    pub events: Vec<DemandEvent>,
}

impl Default for DemandConfig {
    fn default() -> Self {
        Self {
            use_gravity_baseline: true,
            events: vec![],
        }
    }
}

pub fn init_sim_state(s: &Scenario, cfg: &RunConfig) -> SimState {
    let mut st = SimState::new();

    // Start clock at 0
    st.t_s = 0.0;

    // Initialize departure phase for each service’s first boarding stop.
    // (Future: expand to more stops when you model alight/board at intermediate stops.)
    for svc in &s.world.services {
        if let Some(first_stop) = svc.stop_sequence.first() {
            st.time_to_next_departure_s
                .insert((svc.id.clone(), first_stop.clone()), svc.headway_s.max(0.0));
        }
    }

    // Align time bin with config
    // (We don't store bins here yet; state advances via stepping later.)
    let _ = cfg;

    st
}



pub fn run_planning_stateful(
    s: &Scenario,
    cfg: &RunConfig,
    state_in: Option<&SimState>,
) -> Result<(SimulationOutput, SimState), String> {
    // Use existing settings, but override time_bin_s from cfg
    let mut settings = SimulationSettings::from_params(&s.params);
    settings.time_bin_s = cfg.time_bin_s.max(1.0);

    // Run the existing batch model (this remains your trusted kernel)
    let out = run_simulation_with_settings(s, &settings, state_in)?;

    // Build next state from output (queues persist)
    let mut st = state_in.cloned().unwrap_or_else(SimState::new);

    // Advance clock by horizon (planner runs typically simulate full horizon at once)
    st.t_s += cfg.horizon_s.max(0.0);

    // Persist end-of-horizon queues from board_loads
    st.queue.clear();
    for bl in &out.board_loads {
        st.queue
            .insert((bl.service_id.clone(), bl.stop_id.clone()), bl.queue_end.max(0.0));
    }

    st.time_to_next_departure_s.clear();
    for bl in &out.board_loads {
        st.time_to_next_departure_s.insert(
            (bl.service_id.clone(), bl.stop_id.clone()),
            bl.time_to_next_departure_s_end.max(0.0),
        );
    }

    // Future-proof: keep time_to_next_departure_s as-is for now.
    // Next step we will actually advance phase using the discrete departure model.
    // (So trains don’t "reset" each run.)

    Ok((out, st))
}

/// Advance the simulation by one time step `dt_s` using the existing batch kernel.
///
/// What this does (exactly):
/// - Releases baseline gravity demand scaled to `dt_s`.
/// - Injects any DemandEvent::ZoneToZone events whose `t_s` lie in [state.t_s, state.t_s + dt_s).
/// - Runs the trusted batch model for a *period length of dt_s* (capacity/queues/headways are evaluated over dt).
/// - Persists end-of-step queues + departure phases back into SimState.
/// - Advances `state.t_s` by dt_s.
pub fn step_simulation(
    s: &Scenario,
    cfg: &RunConfig,
    state_in: &SimState,
    dt_s: f64,
) -> Result<(SimulationOutput, SimState), String> {
    if dt_s <= 0.0 {
        return Err("dt_s must be > 0".to_string());
    }

    // ---- 1) Build a scenario copy whose period equals this step duration ----
    // The batch kernel interprets demand (trips_per_person) and capacity in terms of the scenario time period.
    // To run the kernel for dt_s, we set time_period_hours accordingly AND scale trips_per_person so that
    // demand per second stays consistent.
    let base_period_s = (s.meta.time_period_hours.max(0.0)) * 3600.0;
    if base_period_s <= 0.0 {
        return Err("scenario.meta.time_period_hours must be > 0".to_string());
    }

    let mut s_step = s.clone();
    s_step.meta.time_period_hours = dt_s / 3600.0;
    s_step.params.trips_per_person = s.params.trips_per_person * (dt_s / base_period_s);

    // ---- 2) Build an outgoing state that includes OD events released this step ----
    let mut st = state_in.clone();
    st.pending_od_trips.clear();

    let t0 = state_in.t_s;
    let t1 = t0 + dt_s;
    for ev in &cfg.demand.events {
        match ev {
            DemandEvent::ZoneToZone { t_s, origin_zone, dest_zone, trips } => {
                if *t_s >= t0 && *t_s < t1 && *trips > 0.0 {
                    *st.pending_od_trips
                        .entry((origin_zone.clone(), dest_zone.clone()))
                        .or_insert(0.0) += *trips;
                }
            }
        }
    }

    // ---- 3) Run the trusted batch kernel for this step ----
    let mut settings = SimulationSettings::from_params(&s_step.params);
    // Ensure bin size is sane for this step
    settings.time_bin_s = cfg.time_bin_s.max(1.0).min(dt_s.max(1.0));

    let out = run_simulation_with_settings(&s_step, &settings, Some(&st))?;

    // ---- 4) Persist next state ----
    let mut next = state_in.clone();
    next.t_s += dt_s;

    next.queue.clear();
    for bl in &out.board_loads {
        next.queue
            .insert((bl.service_id.clone(), bl.stop_id.clone()), bl.queue_end.max(0.0));
    }

    next.time_to_next_departure_s.clear();
    for bl in &out.board_loads {
        next.time_to_next_departure_s.insert(
            (bl.service_id.clone(), bl.stop_id.clone()),
            bl.time_to_next_departure_s_end.max(0.0),
        );
    }

    next.pending_od_trips.clear();
    Ok((out, next))
}
use serde::{Deserialize, Serialize};
use crate::model::Params;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SampleOdPaths {
    pub origin_zone: String,
    pub dest_zone: String,
    pub trips: f64,
    pub k_paths_raw: usize,
    pub k_paths_after_dedupe: usize,
    pub paths: Vec<SamplePathOption>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SamplePathOption {
    pub share: f64,

    pub gc_s: f64,
    pub walk_s: f64,
    pub wait_s: f64,
    pub ivt_s: f64,

    pub transfer_count: f64,
    pub boardings: f64,

    pub link_ids: Vec<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SimulationOutput {
    pub meta: OutputMeta,
    pub kpis: Kpis,
    pub link_loads: Vec<LinkLoad>,
    pub board_loads: Vec<BoardLoad>,
    pub diagnostics: Diagnostics,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct OutputMeta {
    pub results_version: String,
    pub scenario_name: String,
    pub seed: u64,
    pub time_period_hours: f64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SimulationSettings {
    pub k_paths: usize,
    pub route_choice_theta: f64,
    pub msa_max_iters: usize,
    pub convergence_rel: f64,

    // Discrete time step for within-period boarding/queue dynamics (game bridge)
    pub time_bin_s: f64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct BoardingTimeBin {
    pub bin_index: usize,
    pub arrivals: f64,
    pub served: f64,
    pub queue_end: f64,
    pub departures: usize,
    pub capacity: f64,
}

impl SimulationSettings {
    pub fn from_params(p: &Params) -> Self {
        Self {
            k_paths: p.route_choice_k.max(1),
            route_choice_theta: p.route_choice_theta,
            msa_max_iters: p.assignment_max_iters.max(1),
            convergence_rel: p.assignment_convergence_rel.max(0.0),

            // 5-minute bins by default (good for peak modelling + game ticks later)
            time_bin_s: 300.0,
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Kpis {
    // Trips (OD demand)
    pub total_trips_attempted: f64,
    pub total_trips_served: f64,
    pub share_trips_served: f64,

    pub total_trips: f64,

    pub mean_generalized_cost_s: f64,
    pub mean_in_vehicle_time_s: f64,
    pub mean_wait_time_s: f64,
    pub mean_walk_time_s: f64,

    pub mean_transfer_time_s: f64,
    pub mean_transfer_penalty_s: f64,
    pub mean_transfers: f64,

    pub mean_boardings: f64,

    // Boarding/capacity summary (service/stop board edges)
    pub total_boardings_attempted: f64,
    pub total_boardings_served: f64,
    pub total_boardings_denied: f64,
    pub share_boardings_served: f64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct LinkLoad {
    pub link_id: String,
    pub from_stop: String,
    pub to_stop: String,
    pub mode: String,

    pub passengers: f64,

    // --- NEW: crowding diagnostics ---
    pub capacity_per_hour: Option<f64>,
    pub capacity_in_period: f64,      // capacity_per_hour * time_period_hours
    pub load_to_capacity: f64,        // passengers / capacity_in_period
    pub crowding_penalty_s: f64,      // what your crowding function returns for this link
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct BoardLoad {
    pub service_id: String,
    pub stop_id: String,

    pub arrivals: f64,
    pub served_from_arrivals: f64,
    pub served_from_queue: f64,
    pub denied_boardings: f64,
    pub queue_start: f64,
    pub queue_end: f64,

    pub headway_s: f64,
    pub vehicle_capacity: f64,
    pub departures_in_period: f64,
    pub capacity_in_period: f64,

    pub extra_wait_s: f64,

    // NEW: time-sliced queue evolution
    pub time_bins: Vec<BoardingTimeBin>,
    pub time_to_next_departure_s_end: f64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Diagnostics {
    pub zones: usize,
    pub stops: usize,
    pub links: usize,
    pub services: usize,
    pub transfers: usize,
    pub access_edges: usize,
    pub egress_edges: usize,

    // --- NEW: assignment diagnostics ---
    pub msa_iterations: usize,
    pub msa_final_max_rel_change: f64,

    // --- NEW: route-choice debug samples ---
    #[serde(default)]
    pub sample_paths: Vec<SampleOdPaths>,
}
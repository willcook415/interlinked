use std::collections::HashMap;

use crate::model::{Scenario, World};
use super::types::{BoardLoad, Diagnostics, Kpis, LinkLoad, OutputMeta, SimulationOutput, SimulationSettings, SampleOdPaths, SamplePathOption};
use super::choice::logit_shares;
use super::capacity::simulate_boarding_time_sliced;
use super::routing::{build_graph, build_graph_with_costs, dijkstra, dedupe_paths, k_shortest_paths};
use super::stateful::SimState;
use super::routing::crowding_multiplier;

pub fn run_simulation(s: &Scenario) -> Result<SimulationOutput, String> {
    let settings = SimulationSettings::from_params(&s.params);
    run_simulation_with_settings(s, &settings, None)
}

pub fn run_simulation_with_settings(
    s: &Scenario,
    settings: &SimulationSettings,
    state_in: Option<&SimState>,
) -> Result<SimulationOutput, String> {
    validate(s)?;
    let init_queue_map = state_in.map(|st| &st.queue);
    let init_ttn_map = state_in.map(|st| &st.time_to_next_departure_s);
    let pending_od = state_in.map(|st| &st.pending_od_trips);
    let (stop_index, zone_index) = index_maps(&s.world);
    let graph = build_graph(s, &stop_index, &zone_index)?;

    // Pre-index any injected OD trips for this simulation period.
    // These come from the stateful stepping layer and are additive to baseline demand.
    let mut pending_by_origin: HashMap<usize, Vec<(usize, f64)>> = HashMap::new();
    if let Some(m) = pending_od {
        for ((oz, dz), trips) in m.iter() {
            if *trips <= 0.0 {
                continue;
            }
            let oi = match zone_index.get(oz) {
                Some(x) => *x,
                None => continue,
            };
            let dj = match zone_index.get(dz) {
                Some(x) => *x,
                None => continue,
            };
            pending_by_origin.entry(oi).or_default().push((dj, *trips));
        }
    }

    let zone_count = s.world.zones.len();
    let mut service_index: HashMap<String, usize> = HashMap::new();
    for (i, svc) in s.world.services.iter().enumerate() {
        service_index.insert(svc.id.clone(), i);
    }

    // Assignment store: passengers per physical link
    let max_iters = settings.msa_max_iters;
    let mut link_passengers = vec![0.0_f64; s.world.links.len()];
    let mut prev_link_passengers = vec![0.0_f64; s.world.links.len()];

    // Milestone 2: capacity + queueing on boarding edges (service/stop)
    let mut prev_extra_wait: HashMap<(String, String), f64> = HashMap::new();
    let mut final_board_loads: Vec<BoardLoad> = Vec::new();

    let mut iters_run: usize = 0;
    let mut last_max_rel_change: f64 = 0.0;

    // KPI accumulators weighted by trips
    // KPI accumulators
    let mut total_trips_attempted = 0.0_f64;
    let mut total_trips_served = 0.0_f64;

    let mut sum_gc = 0.0_f64;
    let mut sum_walk = 0.0_f64;
    let mut sum_wait = 0.0_f64;
    let mut sum_ivt = 0.0_f64;

    let mut sum_transfer_time = 0.0_f64;
    let mut sum_transfer_pen = 0.0_f64;
    let mut sum_transfers = 0.0_f64;

    let mut sum_boardings = 0.0_f64;

    for iter in 1..=max_iters {
        // Copy previous iteration flows
        prev_link_passengers.clone_from(&link_passengers);

        // Reset flows for this iteration
        link_passengers = vec![0.0_f64; s.world.links.len()];
        let mut attempted_boardings: HashMap<(String, String), f64> = HashMap::new();
        let mut path_records: Vec<(f64, Vec<usize>, Vec<(String, String)>)> = Vec::new();

        // Build graph using current crowding-adjusted ride costs
        let graph = build_graph_with_costs(
            s,
            &stop_index,
            &zone_index,
            &prev_link_passengers,
            &prev_extra_wait,
        )?;

        for oi in 0..zone_count {
            let origin_node = graph.svc_index.zone_nodes_start + oi;

            // Best-path distances for gravity deterrence (one Dijkstra per origin)
            let dist_best = dijkstra(&graph, origin_node);

            let pop_i = s.world.zones[oi].population.max(0.0);
            if pop_i <= 0.0 {
                continue;
            }

            let produced = pop_i * s.params.trips_per_person;

            let mut weights: Vec<(usize, f64)> = Vec::new();
            let mut wsum = 0.0_f64;

            for dj in 0..zone_count {
                if oi == dj {
                    continue;
                }

                let jobs_j = s.world.zones[dj].jobs.max(0.0);
                if jobs_j <= 0.0 {
                    continue;
                }

                let dest_node = graph.svc_index.zone_nodes_start + zone_count + dj;

                let gc_s = dist_best[dest_node].dist;
                if !gc_s.is_finite() {
                    continue;
                }

                let w = jobs_j * (-s.params.gravity_beta * gc_s).exp();
                if w > 0.0 {
                    wsum += w;
                    weights.push((dj, w));
                }
            }

            if wsum <= 0.0 {
                continue;
            }

            for (dj, w) in weights {
                let tij = produced * (w / wsum);
                if tij <= 0.0 {
                    continue;
                }

                let dest_node = graph.svc_index.zone_nodes_start + zone_count + dj;

                                let paths = dedupe_paths(k_shortest_paths(
                    &graph,
                    origin_node,
                    dest_node,
                    settings.k_paths,
                ));
                if paths.is_empty() {
                    continue;
                }

                let shares = logit_shares(&paths, settings.route_choice_theta);

                for (p, sh) in paths.iter().zip(shares.iter()) {
                    let flow = tij * sh;
                    if flow <= 0.0 {
                        continue;
                    }

                    for (svc_id, stop_id) in &p.board_events {
                        *attempted_boardings
                            .entry((svc_id.clone(), stop_id.clone()))
                            .or_insert(0.0) += flow;
                    }

                    path_records.push((flow, p.link_indices.clone(), p.board_events.clone()));
                }
            }

            // --- Injected OD trips (events/game) ---
            if let Some(list) = pending_by_origin.get(&oi) {
                for &(dj, trips) in list {
                    if trips <= 0.0 {
                        continue;
                    }

                    let dest_node = graph.svc_index.zone_nodes_start + zone_count + dj;

                    let paths = dedupe_paths(k_shortest_paths(
                        &graph,
                        origin_node,
                        dest_node,
                        settings.k_paths,
                    ));
                    if paths.is_empty() {
                        continue;
                    }

                    let shares = logit_shares(&paths, settings.route_choice_theta);
                    for (p, sh) in paths.iter().zip(shares.iter()) {
                        let flow = trips * sh;
                        if flow <= 0.0 {
                            continue;
                        }

                        for (svc_id, stop_id) in &p.board_events {
                            *attempted_boardings
                                .entry((svc_id.clone(), stop_id.clone()))
                                .or_insert(0.0) += flow;
                        }
                        path_records.push((flow, p.link_indices.clone(), p.board_events.clone()));
                    }
                }
            }
        }
        // Milestone 2: resolve boarding capacity -> queue -> extra wait for next iteration
        if s.params.capacity_enabled {
            let mut new_extra_wait: HashMap<(String, String), f64> = HashMap::new();
            let mut board_loads_iter: Vec<BoardLoad> = Vec::new();
            let mut served_frac: HashMap<(String, String), f64> = HashMap::new();

            // Union keys: attempted boardings plus any existing queue
            // Keys: only what was attempted THIS iteration (MSA iterations are not time steps)
            let mut keys: Vec<(String, String)> = attempted_boardings.keys().cloned().collect();
            keys.sort();
            keys.dedup();

            for (svc_id, stop_id) in keys {
                let attempted = *attempted_boardings
                    .get(&(svc_id.clone(), stop_id.clone()))
                    .unwrap_or(&0.0);

                let si = *service_index
                    .get(&svc_id)
                    .ok_or_else(|| format!("unknown service_id in boarding map: {svc_id}"))?;
                let svc = &s.world.services[si];

                let veh_cap = svc.vehicle_capacity.max(0.0);
                let period_s = s.meta.time_period_hours * 3600.0;

                                let key = (svc_id.clone(), stop_id.clone());

                let init_q = init_queue_map
                    .and_then(|m| m.get(&key))
                    .copied()
                    .unwrap_or(0.0);

                let init_ttn = init_ttn_map
                    .and_then(|m| m.get(&key))
                    .copied()
                    .unwrap_or_else(|| svc.headway_s.max(0.0));

                let (
                    served,
                    denied,
                    queue_end,
                    extra_wait_s,
                    dep,
                    cap_period,
                    time_bins,
                    time_to_next_end,
                ) = simulate_boarding_time_sliced(
                    attempted,
                    svc.headway_s,
                    veh_cap,
                    period_s,
                    settings.time_bin_s,
                    s.params.queue_max_extra_wait_s,
                    init_q,
                    init_ttn,
                );
                // Served fraction at this boarding point (used to compute carried flows)
                let frac = if attempted > 0.0 { served / attempted } else { 1.0 };
                served_frac.insert(key.clone(), frac);
                if extra_wait_s > 0.0 {
                    new_extra_wait.insert((svc_id.clone(), stop_id.clone()), extra_wait_s);
                }

                board_loads_iter.push(BoardLoad {
                    service_id: svc_id.clone(),
                    stop_id: stop_id.clone(),

                    // All new arrivals this period
                    arrivals: attempted,

                    // We are not distinguishing arrival vs queue service yet
                    served_from_arrivals: served,
                    served_from_queue: 0.0,

                    denied_boardings: denied,

                    queue_start: init_q,
                    queue_end,

                    headway_s: svc.headway_s,
                    vehicle_capacity: veh_cap,
                    departures_in_period: dep,
                    capacity_in_period: cap_period,

                    extra_wait_s,

                    time_bins,
                    time_to_next_departure_s_end: time_to_next_end,
                });
            }

            // Recompute served link flows using the served fractions (denied boardings don't ride)
            link_passengers = vec![0.0_f64; s.world.links.len()];
            for (flow, links, boards) in &path_records {
                let mut mult = 1.0_f64;
                for b in boards {
                    if let Some(f) = served_frac.get(b) {
                        mult = mult.min(*f);
                    }
                }
                let eff_flow = flow * mult;
                if eff_flow <= 0.0 {
                    continue;
                }
                for &li in links {
                    link_passengers[li] += eff_flow;
                }
            }
            // Keep the latest iteration's boarding loads (useful even if we early-stop)
            final_board_loads = board_loads_iter;

            prev_extra_wait = new_extra_wait;
        } else {
            // Capacity disabled: all attempted riders are served
            link_passengers = vec![0.0_f64; s.world.links.len()];
            for (flow, links, _boards) in &path_records {
                if *flow <= 0.0 {
                    continue;
                }
                for &li in links {
                    link_passengers[li] += *flow;
                }
            }
            final_board_loads.clear();
            prev_extra_wait.clear();
        }

        // MSA blending
        let lambda = 1.0 / iter as f64;
        for i in 0..link_passengers.len() {
            link_passengers[i] =
                lambda * link_passengers[i] + (1.0 - lambda) * prev_link_passengers[i];
        }

        iters_run = iter;

        // Convergence: max relative change in link flows
        let mut max_rel = 0.0_f64;
        for i in 0..link_passengers.len() {
            let denom = prev_link_passengers[i].abs().max(1.0); // avoid div-by-zero
            let rel = (link_passengers[i] - prev_link_passengers[i]).abs() / denom;
            if rel > max_rel {
                max_rel = rel;
            }
        }
        last_max_rel_change = max_rel;

        // Stop early if stable
        if max_rel < settings.convergence_rel {
            break;
        }
    }

    // --- KPI pass using final equilibrium-ish flows ---
    let final_graph = build_graph_with_costs(
        s,
        &stop_index,
        &zone_index,
        &link_passengers,
        &prev_extra_wait,
    )?;

    let mut sample_paths: Vec<SampleOdPaths> = Vec::new();
    let sample_limit: usize = 6;

    let mut final_board_frac: HashMap<(String, String), f64> = HashMap::new();
    if s.params.capacity_enabled {
        for bl in &final_board_loads {
            let denom = bl.arrivals.max(0.0);
            let frac = if denom > 0.0 {
                (bl.served_from_arrivals / denom).clamp(0.0, 1.0)
            } else {
                1.0
            };
            final_board_frac.insert((bl.service_id.clone(), bl.stop_id.clone()), frac);
        }
    }

    for oi in 0..zone_count {
        let origin_node = final_graph.svc_index.zone_nodes_start + oi;

        // Best-path distances for gravity deterrence (one Dijkstra per origin)
        let dist_best = dijkstra(&final_graph, origin_node);

        let pop_i = s.world.zones[oi].population.max(0.0);
        if pop_i <= 0.0 {
            continue;
        }

        let produced = pop_i * s.params.trips_per_person;

        let mut weights: Vec<(usize, f64, f64)> = Vec::new(); // (dj, w, gc_s)
        let mut wsum = 0.0_f64;

        for dj in 0..zone_count {
            if oi == dj {
                continue;
            }

            let jobs_j = s.world.zones[dj].jobs.max(0.0);
            if jobs_j <= 0.0 {
                continue;
            }

            let dest_node = final_graph.svc_index.zone_nodes_start + zone_count + dj;

            let gc_s = dist_best[dest_node].dist;
            if !gc_s.is_finite() {
                continue;
            }

            let w = jobs_j * (-s.params.gravity_beta * gc_s).exp();
            if w > 0.0 {
                wsum += w;
                weights.push((dj, w, gc_s));
            }
        }

        if wsum <= 0.0 {
            continue;
        }

        for (dj, w, _gc_s) in weights {
            let tij = produced * (w / wsum);
            if tij <= 0.0 {
                continue;
            }

            let dest_node = final_graph.svc_index.zone_nodes_start + zone_count + dj;

                let raw_paths = k_shortest_paths(
                &final_graph,
                origin_node,
                dest_node,
                settings.k_paths,
            );
            let k_paths_raw = raw_paths.len();

            let paths = dedupe_paths(raw_paths);
            let k_paths_after_dedupe = paths.len();
            if paths.is_empty() {
                continue;
            }

            let shares = logit_shares(&paths, settings.route_choice_theta);

            if sample_paths.len() < sample_limit {
                let origin_zone = s.world.zones[oi].id.clone();
                let dest_zone = s.world.zones[dj].id.clone();

                let mut opts: Vec<SamplePathOption> = Vec::new();
                for (p, sh) in paths.iter().zip(shares.iter()) {
                    let link_ids = p
                        .link_indices
                        .iter()
                        .map(|&li| s.world.links[li].id.clone())
                        .collect::<Vec<_>>();

                    opts.push(SamplePathOption {
                        share: *sh,

                        gc_s: p.stats.gc_s,
                        walk_s: p.stats.walk_s,
                        wait_s: p.stats.wait_s,
                        ivt_s: p.stats.ivt_s,

                        transfer_count: p.stats.transfer_count,
                        boardings: p.stats.boardings,

                        link_ids,
                    });
                }

                sample_paths.push(SampleOdPaths {
                    origin_zone,
                    dest_zone,
                    trips: tij,
                    k_paths_raw,
                    k_paths_after_dedupe,
                    paths: opts,
                });
            }

            for (p, sh) in paths.iter().zip(shares.iter()) {
                let attempted = tij * sh;
                if attempted <= 0.0 {
                    continue;
                }
                total_trips_attempted += attempted;

                // Apply capacity-thinning for served trips
                let mut served = attempted;
                if s.params.capacity_enabled {
                    let mut mult = 1.0_f64;
                    for b in &p.board_events {
                        if let Some(f) = final_board_frac.get(b) {
                            mult = mult.min(*f);
                        }
                    }
                    served *= mult;
                }

                if served <= 0.0 {
                    continue;
                }

                total_trips_served += served;
                sum_gc += served * p.stats.gc_s;
                sum_walk += served * p.stats.walk_s;
                sum_wait += served * p.stats.wait_s;
                sum_ivt += served * p.stats.ivt_s;

                sum_transfer_time += served * p.stats.transfer_time_s;
                sum_transfer_pen += served * p.stats.transfer_penalty_s;
                sum_transfers += served * p.stats.transfer_count;

                sum_boardings += served * p.stats.boardings;
            }
        }
    }

    let mean = |sum: f64| if total_trips_served > 0.0 { sum / total_trips_served } else { 0.0 };

    let tph = s.meta.time_period_hours;

    // --- Derived transit link capacities (service supply -> link capacity) ---
    // For any link that is used by at least one service, we derive capacity_per_hour from:
    // sum_over_services_on_link( departures_per_hour * vehicle_capacity )
    let mut derived_cap_per_hour: HashMap<(String, String, String), f64> = HashMap::new();

    for svc in &s.world.services {
        let headway = svc.headway_s;
        let veh_cap = svc.vehicle_capacity;

        if headway <= 0.0 || veh_cap <= 0.0 {
            continue;
        }

        let departures_per_hour = 3600.0 / headway;
        let seats_per_hour = departures_per_hour * veh_cap;

        // Each consecutive stop pair implies the service uses the link (from -> to) in this direction.
        for w in svc.stop_sequence.windows(2) {
            let from_stop = &w[0];
            let to_stop = &w[1];

            let key = (from_stop.clone(), to_stop.clone(), svc.mode.clone());
            *derived_cap_per_hour.entry(key).or_insert(0.0) += seats_per_hour;
        }
    }

    let link_loads = s
        .world
        .links
        .iter()
        .enumerate()
        .map(|(i, l)| {
            let pax = link_passengers[i];

            let key = (l.from_stop.clone(), l.to_stop.clone(), l.mode.clone());

            // If this link is used by services, we override capacity_per_hour with derived supply.
            // Otherwise we fall back to whatever the scenario provided (e.g., roads, walk links, etc.)
            // If link is used by at least one service, use derived supply.
            // If link mode matches any service mode but is not used by a service in this direction,
            // capacity should be zero (no phantom reverse capacity).
            let cap_ph = if derived_cap_per_hour.contains_key(&key) {
                Some(*derived_cap_per_hour.get(&key).unwrap())
            } else if s.world.services.iter().any(|svc| svc.mode == l.mode) {
                Some(0.0)
            } else {
                l.capacity_per_hour
            };

            let cap_period = cap_ph.unwrap_or(0.0) * tph;
            let ratio = if cap_period > 0.0 { pax / cap_period } else { 0.0 };

            let pen_s = crowding_multiplier(pax, cap_ph, tph);

            LinkLoad {
                link_id: l.id.clone(),
                from_stop: l.from_stop.clone(),
                to_stop: l.to_stop.clone(),
                mode: l.mode.clone(),

                passengers: pax,

                capacity_per_hour: cap_ph,
                capacity_in_period: cap_period,
                load_to_capacity: ratio,
                crowding_penalty_s: pen_s,
            }
        })
        .collect::<Vec<_>>();
        let total_boardings_attempted: f64 =
            final_board_loads.iter().map(|b| b.arrivals).sum();

        let total_boardings_served: f64 =
            final_board_loads.iter().map(|b| b.served_from_arrivals).sum();

        let total_boardings_denied: f64 =
            final_board_loads.iter().map(|b| b.denied_boardings).sum();

        let share_boardings_served = if total_boardings_attempted > 0.0 {
            total_boardings_served / total_boardings_attempted
        } else {
            1.0
        };

        let share_trips_served = if total_trips_attempted > 0.0 {
            total_trips_served / total_trips_attempted
        } else {
            1.0
        };
    Ok(SimulationOutput {
        meta: OutputMeta {
            results_version: "0.2.2".to_string(),
            scenario_name: s.meta.name.clone(),
            seed: s.meta.seed,
            time_period_hours: s.meta.time_period_hours,
        },
        kpis: Kpis {
            total_trips_attempted,
            total_trips_served,
            share_trips_served,

            // Back-compat field: now equals served trips
            total_trips: total_trips_served,

            mean_generalized_cost_s: mean(sum_gc),
            mean_in_vehicle_time_s: mean(sum_ivt),
            mean_wait_time_s: mean(sum_wait),
            mean_walk_time_s: mean(sum_walk),

            mean_transfer_time_s: mean(sum_transfer_time),
            mean_transfer_penalty_s: mean(sum_transfer_pen),
            mean_transfers: mean(sum_transfers),

            mean_boardings: mean(sum_boardings),

            total_boardings_attempted,
            total_boardings_served,
            total_boardings_denied,
            share_boardings_served,
        },
        link_loads,
        board_loads: final_board_loads,
        diagnostics: Diagnostics {
            zones: s.world.zones.len(),
            stops: s.world.stops.len(),
            links: s.world.links.len(),
            services: s.world.services.len(),
            transfers: graph.transfer_edges,
            access_edges: graph.access_edges,
            egress_edges: graph.egress_edges,

            msa_iterations: iters_run,
            msa_final_max_rel_change: last_max_rel_change,
            sample_paths,
        },
    })
}

use super::types::BoardingTimeBin;



fn validate(s: &Scenario) -> Result<(), String> {
    if s.world.zones.is_empty() {
        return Err("world.zones is empty".into());
    }
    if s.world.stops.is_empty() {
        return Err("world.stops is empty".into());
    }
    if s.world.links.is_empty() {
        return Err("world.links is empty".into());
    }
    if s.params.access_walk_speed_mps <= 0.0 {
        return Err("params.access_walk_speed_mps must be > 0".into());
    }
    if s.params.access_radius_m <= 0.0 {
        return Err("params.access_radius_m must be > 0".into());
    }
    if s.params.gravity_beta < 0.0 {
        return Err("params.gravity_beta must be >= 0".into());
    }
    Ok(())
}

fn index_maps(world: &World) -> (HashMap<String, usize>, HashMap<String, usize>) {
    let stop_index = world
        .stops
        .iter()
        .enumerate()
        .map(|(i, st)| (st.id.clone(), i))
        .collect::<HashMap<_, _>>();

    let zone_index = world
        .zones
        .iter()
        .enumerate()
        .map(|(i, z)| (z.id.clone(), i))
        .collect::<HashMap<_, _>>();

    (stop_index, zone_index)
}
use std::collections::{HashMap, HashSet};

use crate::io::IoError;
use crate::model::Scenario;
use crate::{load_scenario_from_path, write_json_to_path};

#[derive(Debug, thiserror::Error)]
pub enum ScenarioError {
    #[error(transparent)]
    Io(#[from] IoError),

    #[error("scenario validation failed:\n{0}")]
    Validation(String),

    #[error("scenario migration failed:\n{0}")]
    Migration(String),
}

/// Versioned wrapper around your Scenario.
/// This is the contract that becomes stable forever.
#[derive(Debug, Clone)]
pub struct ScenarioDocument {
    pub schema_version: u32,
    pub scenario: Scenario,
}

impl ScenarioDocument {
    pub const CURRENT_SCHEMA_VERSION: u32 = 1;

    pub fn new_current(scenario: Scenario) -> Self {
        Self {
            schema_version: Self::CURRENT_SCHEMA_VERSION,
            scenario,
        }
    }
}

/// The “platform API” surface for scenario IO, validation and migration.
/// UI, tooling, and batch runners call this, not io.rs directly.
pub struct ScenarioService;

impl ScenarioService {
    /// Load from path (legacy: scenario.json is just Scenario today).
    /// For now we interpret it as schema v1.
    pub fn load_from_path(path: &str) -> Result<ScenarioDocument, ScenarioError> {
        let scenario = load_scenario_from_path(path)?;
        let doc = ScenarioDocument::new_current(scenario);

        Self::validate(&doc.scenario)?;

        Ok(doc)
    }

    pub fn save_to_path(path: &str, doc: &ScenarioDocument) -> Result<(), ScenarioError> {
        // For now: write the inner scenario exactly as before (backward compatible).
        // Later: you can write a wrapper JSON containing schema_version.
        write_json_to_path(path, &doc.scenario)?;
        Ok(())
    }

    pub fn validate(s: &Scenario) -> Result<(), ScenarioError> {
        validate_scenario(s).map_err(ScenarioError::Validation)
    }

    /// Migration stub. When you add schema changes, implement vN -> vN+1 here.
    pub fn migrate_to_current(doc: ScenarioDocument) -> Result<ScenarioDocument, ScenarioError> {
        if doc.schema_version == ScenarioDocument::CURRENT_SCHEMA_VERSION {
            return Ok(doc);
        }
        Err(ScenarioError::Migration(format!(
            "unsupported schema_version {} (current {})",
            doc.schema_version,
            ScenarioDocument::CURRENT_SCHEMA_VERSION
        )))
    }
}

pub(crate) fn validate_scenario(s: &Scenario) -> Result<(), String> {
    let mut errors: Vec<String> = vec![];

    if s.meta.name.trim().is_empty() {
        errors.push("meta.name must not be empty".to_string());
    }

    // Unique IDs
    ensure_unique_ids("zone", s.world.zones.iter().map(|z| &z.id), &mut errors);
    ensure_unique_ids("stop", s.world.stops.iter().map(|x| &x.id), &mut errors);
    ensure_unique_ids("link", s.world.links.iter().map(|x| &x.id), &mut errors);
    ensure_unique_ids("service", s.world.services.iter().map(|x| &x.id), &mut errors);

    // Reference sets
    let stop_ids: HashSet<&str> = s.world.stops.iter().map(|x| x.id.as_str()).collect();
    let _mode_set: HashSet<&str> = s.world.links.iter().map(|l| l.mode.as_str()).collect();

    // Links reference valid stops
    for l in &s.world.links {
        if !stop_ids.contains(l.from_stop.as_str()) {
            errors.push(format!("link {} from_stop '{}' not found", l.id, l.from_stop));
        }
        if !stop_ids.contains(l.to_stop.as_str()) {
            errors.push(format!("link {} to_stop '{}' not found", l.id, l.to_stop));
        }
        if l.distance_m <= 0.0 {
            errors.push(format!("link {} distance_m must be > 0", l.id));
        }
        if l.speed_mps <= 0.0 {
            errors.push(format!("link {} speed_mps must be > 0", l.id));
        }
    }

    // Services stop_sequence references valid stops
    for sv in &s.world.services {
        if sv.stop_sequence.len() < 2 {
            errors.push(format!("service {} stop_sequence must have >= 2 stops", sv.id));
        }
        for st in &sv.stop_sequence {
            if !stop_ids.contains(st.as_str()) {
                errors.push(format!("service {} references missing stop '{}'", sv.id, st));
            }
        }
        if sv.headway_s <= 0.0 {
            errors.push(format!("service {} headway_s must be > 0", sv.id));
        }
        if sv.vehicle_capacity <= 0.0 {
            errors.push(format!("service {} vehicle_capacity must be > 0", sv.id));
        }
    }

    // Transfers reference valid stops
    for t in &s.world.transfers {
        if !stop_ids.contains(t.from_stop.as_str()) {
            errors.push(format!("transfer from_stop '{}' not found", t.from_stop));
        }
        if !stop_ids.contains(t.to_stop.as_str()) {
            errors.push(format!("transfer to_stop '{}' not found", t.to_stop));
        }
        if t.time_s < 0.0 {
            errors.push(format!("transfer {} -> {} time_s must be >= 0", t.from_stop, t.to_stop));
        }
    }

    // Transfer rules sanity
    if let Some(rules) = &s.world.transfer_rules {
        for r in rules {
            if r.base_time_s < 0.0 {
                errors.push(format!("transfer_rule {}->{} base_time_s must be >= 0", r.from_mode, r.to_mode));
            }
            if r.walk_speed_mps <= 0.0 {
                errors.push(format!("transfer_rule {}->{} walk_speed_mps must be > 0", r.from_mode, r.to_mode));
            }
        }
    }

    // Params sanity
    if s.params.access_walk_speed_mps <= 0.0 {
        errors.push("params.access_walk_speed_mps must be > 0".to_string());
    }
    if s.params.access_radius_m <= 0.0 {
        errors.push("params.access_radius_m must be > 0".to_string());
    }
    if s.params.route_choice_k == 0 {
        errors.push("params.route_choice_k must be >= 1".to_string());
    }

    if errors.is_empty() {
        Ok(())
    } else {
        Ok(Err(errors.join("\n"))?)
    }
}

fn ensure_unique_ids<'a, I>(label: &str, iter: I, errors: &mut Vec<String>)
where
    I: Iterator<Item = &'a String>,
{
    let mut seen: HashMap<&str, usize> = HashMap::new();
    for id in iter {
        *seen.entry(id.as_str()).or_insert(0) += 1;
    }
    for (id, n) in seen {
        if n > 1 {
            errors.push(format!("{label} id '{}' appears {n} times", id));
        }
    }
}
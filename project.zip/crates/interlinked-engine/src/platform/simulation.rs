use crate::sim::{run_simulation_with_settings, SimulationOutput, SimulationSettings};
use crate::sim::{init_sim_state, step_simulation, RunConfig};
use super::{GameState, GameStepOutput, GameStepRequest, ScenarioDocument, ScenarioStore};
use super::edits::apply_network_edits;
use crate::sim::{HistoryConfig, SimHistory};

#[derive(Debug, Clone)]
pub struct PlanningRunOptions {
    pub settings_override: Option<SimulationSettings>,
}

impl Default for PlanningRunOptions {
    fn default() -> Self {
        Self { settings_override: None }
    }
}

pub struct SimulationService;

impl SimulationService {
    /// Planning mode: deterministic batch run that yields KPIs/link loads/etc.
    pub fn run_planning(doc: &ScenarioDocument, opts: PlanningRunOptions) -> Result<SimulationOutput, String> {
        let s = &doc.scenario;
        let settings = match opts.settings_override {
            Some(x) => x,
            None => SimulationSettings::from_params(&s.params),
        };
        run_simulation_with_settings(s, &settings, None)
    }

    /// --------------------------
    /// Game-mode scaffolding
    /// --------------------------
    ///
    /// This is *not* a full passenger microsim yet — this is the clean API hook
    /// you’ll build into later (train movement, station crowding, etc).
    ///
    /// The point: UI/game loop can call step_game() repeatedly without touching sim.rs.

    pub fn init_game_state(doc: &ScenarioDocument) -> GameState {
        let run_cfg = RunConfig::default();
        let sim_state = init_sim_state(&doc.scenario, &run_cfg);
        let history = SimHistory::new(HistoryConfig::default());
        GameState {
            tick_s: 0.0,
            // Store the “authoritative” scenario/network here
            store: ScenarioStore::new(doc.scenario.clone()),
            // Quick metrics cache (optional)
            last_quick_kpis: None,
            run_cfg,
            sim_state,
            history,
        }
    }

    /// Tick the game simulation forward by dt seconds.
    /// For now: we only advance time and (optionally) recompute quick KPIs if requested.
    pub fn step_game(state: &mut GameState, dt_s: f64, req: GameStepRequest) -> Result<GameStepOutput, String> {
        if dt_s <= 0.0 {
            return Err("dt_s must be > 0".to_string());
        }

        state.tick_s += dt_s;

        // Apply edits (network building) — scaffold only.
        // Later: edits should invalidate caches, trigger incremental assignment, spawn vehicles, etc.
        if !req.edits.is_empty() {
            apply_network_edits(&mut state.store, &req.edits)?;
        }

        // Run one stateful simulation step (dt_s) using the trusted batch kernel.
        let scenario_now = state.store.scenario().clone();
        let (out, next_sim_state) = step_simulation(&scenario_now, &state.run_cfg, &state.sim_state, dt_s)?;
        state.sim_state = next_sim_state;
        state.tick_s = state.sim_state.t_s;
        state.last_quick_kpis = Some(out.kpis.clone());
        state.history.push(&out, &state.sim_state);

        Ok(GameStepOutput {
            tick_s: state.tick_s,
            quick_kpis: if req.recompute_quick_kpis { state.last_quick_kpis.clone() } else { None },
        })
    }
}

pub fn history_last_frame(state: &GameState) -> Option<crate::sim::HistoryFrame> {
    state.history.last().cloned()
}

pub fn history_export(state: &GameState) -> crate::sim::SimHistory {
    state.history.clone()
}

pub fn history_clear(state: &mut GameState) {
    state.history.clear();
}
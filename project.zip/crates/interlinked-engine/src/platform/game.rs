use super::{NetworkEdit, ScenarioStore};

#[derive(Debug, Clone)]
pub struct GameState {
    pub tick_s: f64,
    pub store: ScenarioStore,
    pub sim_state: crate::sim::SimState,
    pub run_cfg: crate::sim::RunConfig,
    pub last_quick_kpis: Option<crate::sim::Kpis>,
    pub history: crate::sim::SimHistory,
}

#[derive(Debug, Clone)]
pub struct GameStepRequest {
    pub edits: Vec<NetworkEdit>,
    pub recompute_quick_kpis: bool,
}

impl Default for GameStepRequest {
    fn default() -> Self {
        Self {
            edits: vec![],
            recompute_quick_kpis: false,
        }
    }
}

#[derive(Debug, Clone)]
pub struct GameStepOutput {
    pub tick_s: f64,
    pub quick_kpis: Option<crate::sim::Kpis>,
}